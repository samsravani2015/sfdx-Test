({
    upload: function(component, file, base64Data) {
        var action = component.get("c.saveAttachment");
        action.setParams({
            parentId: component.get("v.recordId"),
            fileName: file.name,
            base64Data: base64Data,
            contentType: file.type
        });
        action.setCallback(this, function(a) {
            //component.set("v.message", a.state==="SUCCESS"?"Image uploaded":"Upload error");
        });
        $A.enqueueAction(action);
        //component.set("v.message", "Uploading...");
    }
})