({
	formatNumber : function(value) {
        
        return value/1000;
		
	}
})